<!DOCTYPE html>
<html>
<head>
    <title>Pixabay API Example</title>
</head>
<body><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<center><form action="<?php echo base_url('members/search'); ?>" method="post">
        <input type="text" name="search_query" placeholder="Search...">
        <input type="submit" value="Search">
    </form></center>
</body>
</html>
